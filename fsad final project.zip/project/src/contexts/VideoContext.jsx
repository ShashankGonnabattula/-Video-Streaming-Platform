import { createContext, useContext, useState, useEffect } from 'react'
import { mockVideos, mockCategories } from '../data/mockData'

const VideoContext = createContext()

export const useVideos = () => useContext(VideoContext)

export const VideoProvider = ({ children }) => {
  const [videos, setVideos] = useState([])
  const [categories, setCategories] = useState([])
  const [featured, setFeatured] = useState([])
  const [trending, setTrending] = useState([])
  const [watchlist, setWatchlist] = useState([])
  const [continueWatching, setContinueWatching] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate API fetch with a delay
    const fetchData = async () => {
      setLoading(true)
      try {
        // Simulating API delay
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        setVideos(mockVideos)
        setCategories(mockCategories)
        
        // Get featured videos (first 5)
        setFeatured(mockVideos.filter(video => video.featured).slice(0, 5))
        
        // Get trending videos (sort by views)
        setTrending([...mockVideos].sort((a, b) => b.views - a.views).slice(0, 10))
        
        // Load watchlist from localStorage if available
        const savedWatchlist = localStorage.getItem('watchlist')
        if (savedWatchlist) {
          setWatchlist(JSON.parse(savedWatchlist))
        }
        
        // Load continue watching from localStorage if available
        const savedContinueWatching = localStorage.getItem('continueWatching')
        if (savedContinueWatching) {
          setContinueWatching(JSON.parse(savedContinueWatching))
        }
      } catch (error) {
        console.error('Error fetching videos:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Save watchlist to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('watchlist', JSON.stringify(watchlist))
  }, [watchlist])

  // Save continue watching to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('continueWatching', JSON.stringify(continueWatching))
  }, [continueWatching])

  const addToWatchlist = (videoId) => {
    if (!watchlist.includes(videoId)) {
      setWatchlist([...watchlist, videoId])
    }
  }

  const removeFromWatchlist = (videoId) => {
    setWatchlist(watchlist.filter(id => id !== videoId))
  }

  const updateContinueWatching = (videoId, progress) => {
    const now = new Date().toISOString()
    const existingIndex = continueWatching.findIndex(item => item.videoId === videoId)
    
    if (existingIndex >= 0) {
      const updated = [...continueWatching]
      updated[existingIndex] = { videoId, progress, lastWatched: now }
      setContinueWatching(updated)
    } else {
      setContinueWatching([...continueWatching, { videoId, progress, lastWatched: now }])
    }
  }

  const getVideosByCategory = (categoryId) => {
    return videos.filter(video => video.categoryId === categoryId)
  }

  const getWatchlistVideos = () => {
    return videos.filter(video => watchlist.includes(video.id))
  }

  const getContinueWatchingVideos = () => {
    return continueWatching
      .sort((a, b) => new Date(b.lastWatched) - new Date(a.lastWatched))
      .map(item => ({
        ...videos.find(v => v.id === item.videoId),
        progress: item.progress,
        lastWatched: item.lastWatched
      }))
  }

  const searchVideos = (query) => {
    const searchTerm = query.toLowerCase()
    return videos.filter(video => 
      video.title.toLowerCase().includes(searchTerm) || 
      video.description.toLowerCase().includes(searchTerm)
    )
  }

  const value = {
    videos,
    categories,
    featured,
    trending,
    watchlist,
    loading,
    addToWatchlist,
    removeFromWatchlist,
    updateContinueWatching,
    getVideosByCategory,
    getWatchlistVideos,
    getContinueWatchingVideos,
    searchVideos,
    isInWatchlist: (videoId) => watchlist.includes(videoId)
  }

  return (
    <VideoContext.Provider value={value}>
      {children}
    </VideoContext.Provider>
  )
}