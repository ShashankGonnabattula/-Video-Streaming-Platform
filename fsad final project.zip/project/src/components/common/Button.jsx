import { motion } from 'framer-motion'

const Button = ({ 
  children, 
  variant = 'primary', 
  className = '', 
  onClick, 
  disabled = false,
  fullWidth = false,
  type = 'button',
  icon = null
}) => {
  const baseClasses = "btn rounded-md font-medium transition-all duration-200 flex items-center justify-center gap-2"
  const variantClasses = {
    primary: "bg-accent-950 hover:bg-accent-600 text-white",
    secondary: "bg-transparent border border-white hover:bg-white/10 text-white",
    outline: "bg-transparent border border-primary-600 text-primary-500 hover:bg-primary-600/10",
    ghost: "bg-transparent hover:bg-white/5 text-white",
    dark: "bg-dark-100 hover:bg-dark-200 text-white",
  }
  
  const widthClass = fullWidth ? "w-full" : ""
  const disabledClass = disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
  
  const buttonClasses = `${baseClasses} ${variantClasses[variant]} ${widthClass} ${disabledClass} ${className}`
  
  return (
    <motion.button
      type={type}
      className={buttonClasses}
      onClick={onClick}
      disabled={disabled}
      whileTap={{ scale: disabled ? 1 : 0.97 }}
      whileHover={{ scale: disabled ? 1 : 1.02 }}
    >
      {icon && icon}
      {children}
    </motion.button>
  )
}

export default Button