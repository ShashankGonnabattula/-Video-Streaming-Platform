import { useState, useEffect } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { FiSearch, FiMenu, FiX, FiUser, FiLogOut, FiBookmark, FiSettings } from 'react-icons/fi'
import { useAuth } from '../../contexts/AuthContext'

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isProfileOpen, setIsProfileOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const { currentUser, logout } = useAuth()
  const navigate = useNavigate()

  // Change navbar background on scroll
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const handleSearchSubmit = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`)
      setSearchQuery('')
    }
  }

  const handleLogout = () => {
    logout()
    navigate('/')
    setIsProfileOpen(false)
  }

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)
  const toggleProfile = () => setIsProfileOpen(!isProfileOpen)

  return (
    <motion.header
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-dark-200/95 backdrop-blur-md shadow-lg py-2' : 'bg-gradient-to-b from-dark-300 to-transparent py-4'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container-custom flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <motion.div 
            className="text-accent-950 font-bold text-3xl mr-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            StreamVista
          </motion.div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <NavLink to="/" 
            className={({ isActive }) => 
              `text-white hover:text-accent-950 transition-colors ${isActive ? 'font-semibold text-accent-950' : ''}`
            }
          >
            Home
          </NavLink>
          <NavLink to="/browse" 
            className={({ isActive }) => 
              `text-white hover:text-accent-950 transition-colors ${isActive ? 'font-semibold text-accent-950' : ''}`
            }
          >
            Browse
          </NavLink>
          {currentUser && (
            <NavLink to="/watchlist" 
              className={({ isActive }) => 
                `text-white hover:text-accent-950 transition-colors ${isActive ? 'font-semibold text-accent-950' : ''}`
              }
            >
              Watchlist
            </NavLink>
          )}
          {currentUser?.isAdmin && (
            <NavLink to="/admin" 
              className={({ isActive }) => 
                `text-white hover:text-accent-950 transition-colors ${isActive ? 'font-semibold text-accent-950' : ''}`
              }
            >
              Admin
            </NavLink>
          )}
        </nav>

        {/* Right Side - Search & User */}
        <div className="flex items-center space-x-4">
          {/* Search */}
          <form onSubmit={handleSearchSubmit} className="hidden md:flex items-center relative">
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-dark-100/70 rounded-full pl-10 pr-4 py-2 text-sm text-white 
                        focus:outline-none focus:ring-2 focus:ring-accent-950 w-40 lg:w-56
                        transition-all duration-300"
            />
            <FiSearch className="absolute left-3 text-gray-400" />
          </form>

          {/* User Menu */}
          {currentUser ? (
            <div className="relative">
              <button
                onClick={toggleProfile}
                className="flex items-center space-x-2"
                aria-label="User menu"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-9 h-9 rounded-full object-cover border-2 border-accent-950"
                />
              </button>

              {/* Profile Dropdown */}
              <AnimatePresence>
                {isProfileOpen && (
                  <motion.div
                    className="absolute right-0 mt-2 w-48 bg-dark-100 rounded-md shadow-lg overflow-hidden z-50"
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="px-4 py-3 border-b border-gray-700">
                      <div className="font-semibold text-white">{currentUser.name}</div>
                      <div className="text-sm text-gray-400">{currentUser.email}</div>
                    </div>
                    <Link
                      to="/profile"
                      className="block px-4 py-2 text-sm text-white hover:bg-dark-200 flex items-center"
                      onClick={() => setIsProfileOpen(false)}
                    >
                      <FiUser className="mr-2" /> Profile
                    </Link>
                    <Link
                      to="/watchlist"
                      className="block px-4 py-2 text-sm text-white hover:bg-dark-200 flex items-center"
                      onClick={() => setIsProfileOpen(false)}
                    >
                      <FiBookmark className="mr-2" /> Watchlist
                    </Link>
                    <Link
                      to="/profile"
                      className="block px-4 py-2 text-sm text-white hover:bg-dark-200 flex items-center"
                      onClick={() => setIsProfileOpen(false)}
                    >
                      <FiSettings className="mr-2" /> Settings
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-sm text-white hover:bg-dark-200 flex items-center"
                    >
                      <FiLogOut className="mr-2" /> Logout
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <Link
              to="/login"
              className="py-2 px-4 bg-accent-950 hover:bg-accent-600 text-white rounded-md text-sm transition-colors duration-200"
            >
              Sign In
            </Link>
          )}

          {/* Mobile menu button */}
          <button
            onClick={toggleMenu}
            className="md:hidden text-white p-2"
            aria-label="Menu"
          >
            {isMenuOpen ? <FiX size={24} /> : <FiMenu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            className="md:hidden bg-dark-200 absolute w-full shadow-lg"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="container mx-auto py-4 px-4">
              <form onSubmit={handleSearchSubmit} className="mb-4">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-dark-100 rounded-md w-full pl-10 pr-4 py-2 text-white 
                             focus:outline-none focus:ring-2 focus:ring-accent-950"
                  />
                  <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                </div>
              </form>
              <nav className="flex flex-col space-y-3">
                <NavLink
                  to="/"
                  className={({ isActive }) =>
                    `text-white py-2 px-4 rounded-md ${isActive ? 'bg-dark-100 font-semibold' : 'hover:bg-dark-100'}`
                  }
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </NavLink>
                <NavLink
                  to="/browse"
                  className={({ isActive }) =>
                    `text-white py-2 px-4 rounded-md ${isActive ? 'bg-dark-100 font-semibold' : 'hover:bg-dark-100'}`
                  }
                  onClick={() => setIsMenuOpen(false)}
                >
                  Browse
                </NavLink>
                {currentUser && (
                  <NavLink
                    to="/watchlist"
                    className={({ isActive }) =>
                      `text-white py-2 px-4 rounded-md ${isActive ? 'bg-dark-100 font-semibold' : 'hover:bg-dark-100'}`
                    }
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Watchlist
                  </NavLink>
                )}
                {currentUser?.isAdmin && (
                  <NavLink
                    to="/admin"
                    className={({ isActive }) =>
                      `text-white py-2 px-4 rounded-md ${isActive ? 'bg-dark-100 font-semibold' : 'hover:bg-dark-100'}`
                    }
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Admin
                  </NavLink>
                )}
                {!currentUser && (
                  <>
                    <NavLink
                      to="/login"
                      className="py-2 px-4 bg-accent-950 hover:bg-accent-600 text-white rounded-md text-center"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Sign In
                    </NavLink>
                    <NavLink
                      to="/register"
                      className="py-2 px-4 border border-white text-white rounded-md text-center hover:bg-white/10"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Sign Up
                    </NavLink>
                  </>
                )}
              </nav>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  )
}

export default Navbar