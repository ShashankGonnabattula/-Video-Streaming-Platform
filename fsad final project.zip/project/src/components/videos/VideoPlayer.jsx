import { useState, useEffect, useRef } from 'react'
import { FiPlay, FiPause, FiVolume2, FiVolumeX, FiMaximize, FiMinimize } from 'react-icons/fi'
import { useVideos } from '../../contexts/VideoContext'

const VideoPlayer = ({ video, autoPlay = false }) => {
  const videoRef = useRef(null)
  const playerRef = useRef(null)
  const [isPlaying, setIsPlaying] = useState(autoPlay)
  const [isMuted, setIsMuted] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [showControls, setShowControls] = useState(true)
  const [volume, setVolume] = useState(1)
  const { updateContinueWatching } = useVideos()
  const controlsTimeoutRef = useRef(null)

  // Handle video loading metadata
  useEffect(() => {
    const videoElement = videoRef.current
    
    const handleLoadedMetadata = () => {
      setDuration(videoElement.duration)
    }
    
    videoElement.addEventListener('loadedmetadata', handleLoadedMetadata)
    
    return () => {
      videoElement.removeEventListener('loadedmetadata', handleLoadedMetadata)
    }
  }, [video])
  
  // Auto-hide controls after inactivity
  useEffect(() => {
    const handleMouseMove = () => {
      setShowControls(true)
      clearTimeout(controlsTimeoutRef.current)
      
      controlsTimeoutRef.current = setTimeout(() => {
        if (isPlaying) {
          setShowControls(false)
        }
      }, 3000)
    }
    
    const playerElement = playerRef.current
    playerElement.addEventListener('mousemove', handleMouseMove)
    
    return () => {
      playerElement.removeEventListener('mousemove', handleMouseMove)
      clearTimeout(controlsTimeoutRef.current)
    }
  }, [isPlaying])
  
  // Track progress and update continue watching
  useEffect(() => {
    const videoElement = videoRef.current
    
    const handleTimeUpdate = () => {
      setCurrentTime(videoElement.currentTime)
      
      const progress = (videoElement.currentTime / videoElement.duration) * 100
      if (progress > 5) { // Only update if watched more than 5%
        updateContinueWatching(video.id, progress)
      }
    }
    
    videoElement.addEventListener('timeupdate', handleTimeUpdate)
    
    return () => {
      videoElement.removeEventListener('timeupdate', handleTimeUpdate)
    }
  }, [video.id, updateContinueWatching])
  
  // Play/pause
  const togglePlay = () => {
    if (isPlaying) {
      videoRef.current.pause()
    } else {
      videoRef.current.play()
    }
    setIsPlaying(!isPlaying)
  }
  
  // Mute/unmute
  const toggleMute = () => {
    setIsMuted(!isMuted)
    videoRef.current.muted = !isMuted
  }
  
  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      playerRef.current.requestFullscreen().catch(err => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`)
      })
    } else {
      document.exitFullscreen()
    }
  }
  
  // Update fullscreen state on change
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }
    
    document.addEventListener('fullscreenchange', handleFullscreenChange)
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange)
    }
  }, [])
  
  // Handle volume change
  const handleVolumeChange = (e) => {
    const newVolume = parseFloat(e.target.value)
    setVolume(newVolume)
    videoRef.current.volume = newVolume
    setIsMuted(newVolume === 0)
  }
  
  // Handle seeking
  const handleSeek = (e) => {
    const seekTime = (e.target.value / 100) * duration
    videoRef.current.currentTime = seekTime
    setCurrentTime(seekTime)
  }
  
  // Format time (seconds to MM:SS)
  const formatTime = (timeInSeconds) => {
    const minutes = Math.floor(timeInSeconds / 60)
    const seconds = Math.floor(timeInSeconds % 60)
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`
  }

  return (
    <div 
      ref={playerRef}
      className="video-player relative w-full aspect-video bg-black rounded-lg overflow-hidden"
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => isPlaying && setShowControls(false)}
    >
      <video
        ref={videoRef}
        src={video.video}
        className="w-full h-full object-contain"
        poster={video.thumbnail}
        autoPlay={autoPlay}
        onClick={togglePlay}
        onEnded={() => setIsPlaying(false)}
      />
      
      {/* Video title overlay (top) */}
      <div className={`absolute top-0 left-0 w-full p-4 bg-gradient-to-b from-black/70 to-transparent transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <h3 className="text-white text-xl font-semibold">{video.title}</h3>
      </div>
      
      {/* Play/Pause big button overlay (center) */}
      {!isPlaying && (
        <div className="absolute inset-0 flex items-center justify-center">
          <button 
            onClick={togglePlay}
            className="bg-accent-950/80 hover:bg-accent-950 text-white rounded-full w-16 h-16 flex items-center justify-center transition-all"
            aria-label="Play"
          >
            <FiPlay size={32} />
          </button>
        </div>
      )}
      
      {/* Controls overlay (bottom) */}
      <div 
        className={`absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-black/80 to-transparent transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
      >
        {/* Progress bar */}
        <div className="relative w-full group">
          <input
            type="range"
            min="0"
            max="100"
            value={(currentTime / duration) * 100 || 0}
            onChange={handleSeek}
            className="w-full h-1 bg-gray-600 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-accent-950 [&::-webkit-slider-thumb]:opacity-0 group-hover:[&::-webkit-slider-thumb]:opacity-100"
          />
          <div 
            className="absolute top-0 left-0 h-1 bg-accent-950 rounded-full pointer-events-none"
            style={{ width: `${(currentTime / duration) * 100 || 0}%` }}
          />
        </div>
        
        {/* Control buttons */}
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center space-x-4">
            {/* Play/Pause */}
            <button 
              onClick={togglePlay}
              className="text-white hover:text-accent-950 transition-colors"
              aria-label={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <FiPause size={20} /> : <FiPlay size={20} />}
            </button>
            
            {/* Volume */}
            <div className="flex items-center space-x-2">
              <button 
                onClick={toggleMute}
                className="text-white hover:text-accent-950 transition-colors"
                aria-label={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted || volume === 0 ? <FiVolumeX size={20} /> : <FiVolume2 size={20} />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={volume}
                onChange={handleVolumeChange}
                className="w-16 h-1 bg-gray-600 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-2 [&::-webkit-slider-thumb]:h-2 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white"
              />
            </div>
            
            {/* Time */}
            <div className="text-white text-sm">
              {formatTime(currentTime)} / {formatTime(duration)}
            </div>
          </div>
          
          {/* Fullscreen */}
          <button 
            onClick={toggleFullscreen}
            className="text-white hover:text-accent-950 transition-colors"
            aria-label={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <FiMinimize size={20} /> : <FiMaximize size={20} />}
          </button>
        </div>
      </div>
    </div>
  )
}

export default VideoPlayer