import { useState } from 'react'
import { motion } from 'framer-motion'
import { useVideos } from '../../contexts/VideoContext'

const CategoryList = ({ onCategorySelect, selectedCategory = null }) => {
  const { categories } = useVideos()
  const [isOpen, setIsOpen] = useState(false)

  const handleCategorySelect = (category) => {
    onCategorySelect(category)
    if (window.innerWidth < 768) {
      setIsOpen(false)
    }
  }

  const getSelectedCategoryName = () => {
    if (!selectedCategory) return 'All Categories'
    
    const category = categories.find(c => c.id === selectedCategory)
    return category ? `${category.icon} ${category.name}` : 'All Categories'
  }

  return (
    <div className="mb-8">
      {/* Mobile Dropdown */}
      <div className="md:hidden relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full bg-dark-200 text-white py-3 px-4 rounded-lg flex justify-between items-center"
        >
          <span>{getSelectedCategoryName()}</span>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`h-5 w-5 transform transition-transform ${isOpen ? 'rotate-180' : ''}`}
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
              clipRule="evenodd"
            />
          </svg>
        </button>
        
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute z-10 mt-2 w-full bg-dark-200 rounded-lg shadow-lg py-2 max-h-80 overflow-y-auto"
          >
            <button
              onClick={() => handleCategorySelect(null)}
              className={`block w-full text-left px-4 py-2 hover:bg-dark-100 ${
                !selectedCategory ? 'bg-dark-100 text-accent-950' : 'text-white'
              }`}
            >
              All Categories
            </button>
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => handleCategorySelect(category.id)}
                className={`block w-full text-left px-4 py-2 hover:bg-dark-100 ${
                  selectedCategory === category.id ? 'bg-dark-100 text-accent-950' : 'text-white'
                }`}
              >
                {category.icon} {category.name}
              </button>
            ))}
          </motion.div>
        )}
      </div>
      
      {/* Desktop Horizontal List */}
      <div className="hidden md:block">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => onCategorySelect(null)}
            className={`px-4 py-2 rounded-full transition-colors ${
              !selectedCategory 
                ? 'bg-accent-950 text-white' 
                : 'bg-dark-200 text-white hover:bg-dark-100'
            }`}
          >
            All
          </button>
          
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => onCategorySelect(category.id)}
              className={`px-4 py-2 rounded-full transition-colors ${
                selectedCategory === category.id 
                  ? 'bg-accent-950 text-white' 
                  : 'bg-dark-200 text-white hover:bg-dark-100'
              }`}
            >
              {category.icon} {category.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

export default CategoryList