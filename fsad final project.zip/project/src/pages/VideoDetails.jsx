import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FiArrowLeft, FiPlus, FiCheck, FiShare2 } from 'react-icons/fi'
import { useVideos } from '../contexts/VideoContext'
import VideoPlayer from '../components/videos/VideoPlayer'
import VideoGrid from '../components/videos/VideoGrid'
import Button from '../components/common/Button'
import Loading from '../components/common/Loading'

const VideoDetails = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const { 
    videos, 
    addToWatchlist, 
    removeFromWatchlist, 
    isInWatchlist,
    getVideosByCategory,
    loading
  } = useVideos()
  
  const [video, setVideo] = useState(null)
  const [relatedVideos, setRelatedVideos] = useState([])
  
  useEffect(() => {
    if (!loading) {
      const foundVideo = videos.find(v => v.id === id)
      
      if (foundVideo) {
        setVideo(foundVideo)
        
        // Get related videos from same category
        const related = getVideosByCategory(foundVideo.categoryId)
          .filter(v => v.id !== foundVideo.id)
          .slice(0, 4)
          
        setRelatedVideos(related)
      } else {
        // Video not found, redirect
        navigate('/not-found')
      }
    }
  }, [id, videos, navigate, getVideosByCategory, loading])
  
  if (loading || !video) {
    return <Loading />
  }
  
  const inWatchlist = isInWatchlist(video.id)
  
  const handleWatchlistToggle = () => {
    if (inWatchlist) {
      removeFromWatchlist(video.id)
    } else {
      addToWatchlist(video.id)
    }
  }
  
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: video.title,
        text: video.description,
        url: window.location.href
      })
    } else {
      navigator.clipboard.writeText(window.location.href)
        .then(() => {
          alert('Link copied to clipboard')
        })
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container-custom py-24">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-400 hover:text-white mb-6 transition-colors"
        >
          <FiArrowLeft className="mr-2" /> Back
        </button>
        
        {/* Video Player */}
        <VideoPlayer video={video} />
        
        {/* Video Info */}
        <div className="mt-6 mb-10">
          <div className="flex flex-wrap justify-between items-start">
            <div className="mb-4 md:mb-0">
              <h1 className="heading-lg mb-2">{video.title}</h1>
              <div className="flex flex-wrap items-center text-gray-400 mb-2 gap-2">
                <span>{video.releaseYear}</span>
                <span className="mx-1">•</span>
                <span>{video.duration}</span>
                <span className="mx-1">•</span>
                <span className="flex items-center">
                  {video.rating} <span className="text-yellow-500 ml-1">★</span>
                </span>
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button
                onClick={handleWatchlistToggle}
                variant={inWatchlist ? "secondary" : "primary"}
                icon={inWatchlist ? <FiCheck /> : <FiPlus />}
              >
                {inWatchlist ? 'In Watchlist' : 'Add to Watchlist'}
              </Button>
              
              <Button
                onClick={handleShare}
                variant="dark"
                icon={<FiShare2 />}
              >
                Share
              </Button>
            </div>
          </div>
          
          {/* Description */}
          <p className="text-gray-300 my-6 max-w-3xl">
            {video.description}
          </p>
          
          {/* Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8 mb-12 max-w-3xl">
            <div>
              <h3 className="text-sm font-semibold text-gray-400 mb-2">Cast</h3>
              <p className="text-white">
                {video.cast.join(', ')}
              </p>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-400 mb-2">Director</h3>
              <p className="text-white">
                {video.director}
              </p>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-400 mb-2">Views</h3>
              <p className="text-white">
                {video.views.toLocaleString()}
              </p>
            </div>
          </div>
        </div>
        
        {/* Related Videos */}
        {relatedVideos.length > 0 && (
          <VideoGrid
            videos={relatedVideos}
            title="You May Also Like"
          />
        )}
      </div>
    </motion.div>
  )
}

export default VideoDetails