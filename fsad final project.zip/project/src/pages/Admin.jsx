import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { FiFilm, FiUsers, FiActivity, FiPlus, FiEdit2, FiTrash2 } from 'react-icons/fi'
import { useVideos } from '../contexts/VideoContext'
import Button from '../components/common/Button'
import Loading from '../components/common/Loading'

const Admin = () => {
  const { videos, categories, loading } = useVideos()
  const [activeTab, setActiveTab] = useState('videos')
  const [stats, setStats] = useState({
    totalVideos: 0,
    totalViews: 0,
    featuredVideos: 0,
    categories: 0
  })
  
  useEffect(() => {
    if (!loading) {
      setStats({
        totalVideos: videos.length,
        totalViews: videos.reduce((acc, video) => acc + video.views, 0),
        featuredVideos: videos.filter(video => video.featured).length,
        categories: categories.length
      })
    }
  }, [videos, categories, loading])
  
  if (loading) {
    return <Loading />
  }

  return (
    <motion.div
      className="container-custom py-24"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <h1 className="heading-lg mb-4 md:mb-0">Admin Dashboard</h1>
        <Button
          variant="primary"
          icon={<FiPlus />}
        >
          Add New Video
        </Button>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-dark-200 rounded-lg p-6">
          <div className="flex items-center mb-4">
            <FiFilm className="text-accent-950 mr-3" size={24} />
            <h3 className="font-semibold text-lg">Total Videos</h3>
          </div>
          <p className="text-3xl font-bold">{stats.totalVideos}</p>
        </div>
        <div className="bg-dark-200 rounded-lg p-6">
          <div className="flex items-center mb-4">
            <FiUsers className="text-primary-500 mr-3" size={24} />
            <h3 className="font-semibold text-lg">Total Views</h3>
          </div>
          <p className="text-3xl font-bold">{stats.totalViews.toLocaleString()}</p>
        </div>
        <div className="bg-dark-200 rounded-lg p-6">
          <div className="flex items-center mb-4">
            <FiActivity className="text-secondary-950 mr-3" size={24} />
            <h3 className="font-semibold text-lg">Featured Videos</h3>
          </div>
          <p className="text-3xl font-bold">{stats.featuredVideos}</p>
        </div>
        <div className="bg-dark-200 rounded-lg p-6">
          <div className="flex items-center mb-4">
            <FiActivity className="text-warning-500 mr-3" size={24} />
            <h3 className="font-semibold text-lg">Categories</h3>
          </div>
          <p className="text-3xl font-bold">{stats.categories}</p>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="mb-6">
        <div className="border-b border-gray-700">
          <nav className="flex -mb-px">
            <button
              className={`py-4 px-6 font-medium text-sm border-b-2 ${
                activeTab === 'videos'
                  ? 'border-accent-950 text-accent-950'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('videos')}
            >
              Videos
            </button>
            <button
              className={`py-4 px-6 font-medium text-sm border-b-2 ${
                activeTab === 'categories'
                  ? 'border-accent-950 text-accent-950'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('categories')}
            >
              Categories
            </button>
            <button
              className={`py-4 px-6 font-medium text-sm border-b-2 ${
                activeTab === 'users'
                  ? 'border-accent-950 text-accent-950'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('users')}
            >
              Users
            </button>
          </nav>
        </div>
      </div>
      
      {/* Content */}
      <div className="bg-dark-200 rounded-lg overflow-hidden">
        {activeTab === 'videos' && (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-dark-100">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Title
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Category
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Year
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Views
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Rating
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Featured
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {videos.map((video) => (
                  <tr key={video.id} className="hover:bg-dark-100">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <img 
                          src={video.thumbnail} 
                          alt={video.title} 
                          className="h-10 w-16 object-cover rounded mr-3"
                        />
                        <div className="text-sm font-medium text-white">
                          {video.title}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {categories.find(c => c.id === video.categoryId)?.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {video.releaseYear}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {video.views.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {video.rating}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {video.featured ? (
                        <span className="px-2 py-1 bg-accent-950/20 text-accent-950 rounded-full text-xs">
                          Featured
                        </span>
                      ) : (
                        <span className="px-2 py-1 bg-gray-700/20 text-gray-400 rounded-full text-xs">
                          No
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button className="text-primary-500 hover:text-primary-400 mr-3">
                        <FiEdit2 size={18} />
                      </button>
                      <button className="text-error-500 hover:text-error-400">
                        <FiTrash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        
        {activeTab === 'categories' && (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-dark-100">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Name
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Icon
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Videos
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {categories.map((category) => (
                  <tr key={category.id} className="hover:bg-dark-100">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                      {category.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {category.icon}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {videos.filter(video => video.categoryId === category.id).length}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button className="text-primary-500 hover:text-primary-400 mr-3">
                        <FiEdit2 size={18} />
                      </button>
                      <button className="text-error-500 hover:text-error-400">
                        <FiTrash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        
        {activeTab === 'users' && (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-dark-100">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    User
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Email
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Role
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {[
                  { id: 1, name: 'John Doe', email: 'user@example.com', role: 'User', status: 'Active', avatar: 'https://i.pravatar.cc/150?img=33' },
                  { id: 2, name: 'Admin User', email: 'admin@example.com', role: 'Admin', status: 'Active', avatar: 'https://i.pravatar.cc/150?img=68' },
                  { id: 3, name: 'Jane Smith', email: 'jane@example.com', role: 'User', status: 'Inactive', avatar: 'https://i.pravatar.cc/150?img=5' }
                ].map((user) => (
                  <tr key={user.id} className="hover:bg-dark-100">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <img 
                            className="h-10 w-10 rounded-full" 
                            src={user.avatar} 
                            alt={user.name} 
                          />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-white">
                            {user.name}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {user.email}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {user.role === 'Admin' ? (
                        <span className="px-2 py-1 bg-primary-500/20 text-primary-400 rounded-full text-xs">
                          Admin
                        </span>
                      ) : (
                        <span className="px-2 py-1 bg-gray-700/20 text-gray-400 rounded-full text-xs">
                          User
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {user.status === 'Active' ? (
                        <span className="px-2 py-1 bg-success-500/20 text-success-500 rounded-full text-xs">
                          Active
                        </span>
                      ) : (
                        <span className="px-2 py-1 bg-error-500/20 text-error-500 rounded-full text-xs">
                          Inactive
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button className="text-primary-500 hover:text-primary-400 mr-3">
                        <FiEdit2 size={18} />
                      </button>
                      <button className="text-error-500 hover:text-error-400">
                        <FiTrash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </motion.div>
  )
}

export default Admin