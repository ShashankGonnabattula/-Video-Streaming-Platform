import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FiUser, FiLock, FiAlertCircle } from 'react-icons/fi'
import { useAuth } from '../contexts/AuthContext'
import Input from '../components/common/Input'
import Button from '../components/common/Button'

const Login = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  // Get redirect path from location state or default to home
  const from = location.state?.from?.pathname || '/'

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    
    try {
      setLoading(true)
      await login(email, password)
      navigate(from, { replace: true })
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <motion.div
      className="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="w-full max-w-md bg-dark-200 p-8 rounded-lg shadow-lg">
        <div className="text-center mb-8">
          <h1 className="heading-lg mb-2">Welcome Back</h1>
          <p className="text-gray-400">Sign in to continue to StreamVista</p>
        </div>
        
        {error && (
          <div className="bg-error-500/10 border border-error-500 text-white p-4 rounded-md mb-6 flex items-start">
            <FiAlertCircle className="text-error-500 mr-2 mt-0.5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Input
              label="Email"
              type="email"
              placeholder="your.email@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              icon={<FiUser />}
            />
          </div>
          <div>
            <Input
              label="Password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              icon={<FiLock />}
            />
          </div>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center">
              <input
                id="remember-me"
                name="remember-me"
                type="checkbox"
                className="h-4 w-4 bg-dark-100 border-gray-700 rounded focus:ring-accent-950"
              />
              <label htmlFor="remember-me" className="ml-2 text-gray-300">
                Remember me
              </label>
            </div>
            <div>
              <a href="#" className="text-accent-950 hover:text-accent-600">
                Forgot password?
              </a>
            </div>
          </div>
          <div>
            <Button
              type="submit"
              fullWidth
              disabled={loading}
            >
              {loading ? 'Signing in...' : 'Sign in'}
            </Button>
          </div>
        </form>
        
        <div className="mt-6 text-center text-sm">
          <span className="text-gray-400">Don't have an account?</span>
          <Link to="/register" className="ml-1 text-accent-950 hover:text-accent-600">
            Sign up
          </Link>
        </div>
        
        <div className="mt-8 border-t border-gray-700 pt-6 text-center text-xs text-gray-500">
          <p>Demo credentials:</p>
          <p className="mt-1">User: user@example.com / password</p>
          <p>Admin: admin@example.com / admin</p>
        </div>
      </div>
    </motion.div>
  )
}

export default Login